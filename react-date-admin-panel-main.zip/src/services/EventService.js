import axios from "axios";
// const apiClient =axios.create({
//     baseURL : `https://encounter.generalrouter.ir`,
//     headers: {
//         'Content-Type': 'application/json',
//         'Accept': 'application/json',
//     }
// })
// export default apiClient

export const ADMIN = {
    email : 'admin@yahoo.com',
    password : '12345678'
} 

 export const userData = {
     
        userCount : 5 , 
        likeCount :3 ,
        matchCount : 34,
        lastMonth : '2020-11-13',
        matchCountLastMonth : 4,
        likeCountLastMonth : 66,
        userActivityAction :[
            {
                user1 :'mike',
                user2:'saeed',
                action : 'like'
            }
        ],
        userCountLastMonth : 51,
        userCountLastTwoMonth : 66,
        matchCountLastTwoMonth : 52,
        PremiumUserCountLastMonth : 87,
        PremiumUserLikeCountLastTwoMonth : 75,
        userCountLastWeek : 33,
        userCountLastTwoWeek :45,
        matchCountLastWeek : 32,
        matchCountLastTwoWeek : 34,        
        PremiumUserCountLastWeek : 54,
        PremiumUserLikeCountLastTwoWeek : 54,
        userCountLastDay : 11,
        userCountLastTwoDay : 6,
        matchCountLastDay :4,
        matchCountLastTwoDay : 3,
        PremiumUserCountLastDay:2,
        PremiumUserLikeCountLastTwoDay :5,



 }
 export const apiClient =[]